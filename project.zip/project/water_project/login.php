<?php
include('includes/config.php');
$mssg=null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Login</title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap-theme.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/user-styles.css" rel="stylesheet">
    <link href="assets/fonts/glyphicons-halflings-regular.eot" rel="stylesheet">
</head>
<?php include("includes/navigation.php"); ?>

    
  
<body>

    <div class="container">
        
        <div class="col-md-4"></div>
    
        <div class="col-md-4">

            <form method="post" action="#">
                <div class="form-group">
                    <label for="exampleInputEmail1">Username</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter your username here.." required name="username">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" required name="password">
                </div>
                
               

                <button type="submit" class="btn btn-default" name="send_datas">Submit</button>
            </form>
        </div>
    </div>
    
    <?php
    if(isset($_POST['send_datas'])) {
      
        	// Getting username/ email and password
    $uname=$_POST['username'];
    $password=$_POST['password'];
    // Fetch data from database on the basis of username/email and password
$sql =mysqli_query($con,"SELECT * FROM users WHERE username='$uname' and password='$password'");
 $num=mysqli_fetch_array($sql);
//    while($row=mysqli_fetch_array($sql)) {
            if($num['types']=="Admin") {                 
                        echo "<script type='text/javascript'> document.location = 'admin/'; </script>";
                                
            }elseif ($num['types']=="client") {
                 echo "<script type='text/javascript'> document.location = 'http://www.google.com'; </script>";
                
            }else {
                $mssg="User not registered with us";
                
            } 
        }

    ?>




</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="assets/js/bootstrap.js"></script>
<script src="assets/js/npm.js"></script>

</html>
