?php
	require_once 'conn.php';
	
	if(ISSET($_POST['save'])){
		
        $user-id= $_POST['user-id'];
        $names= $_POST['names'];
		$tel = $_POST['tel'];
		$Id-card = $_POST['Id-card'];
        $types = $_POST['types'];
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = $_POST['password'];
		
		mysqli_query($conn, "INSERT INTO `users` VALUES('', '$user-id', '$names', '$tel', '$id-card','types','email','username','password')") or die(mysqli_error());
		
<?php include('includes/left-side.php')?>


		header("location: index.php");
	}
?>