<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
   
    <title>WATER QUALITY MONITORING SYSTEM</title>

    <!-- Bootstrap -->
    <link href="assets/css/bootstrap-theme.css" rel="stylesheet">
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <link href="assets/css/bootstrap-theme.min.css" rel="stylesheet">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/user-styles.css" rel="stylesheet">
    <link href="assets/fonts/glyphicons-halflings-regular.eot" rel="stylesheet">
 
    <link rel="logo" type="image/logo" href="image/logo/logo.jpg" />
    
      
    

      
      
      
      
    </head>
    <?php include("includes/navigation.php"); ?>   
     <?php include("includes/config.php"); ?>   


  
    
    <body>
      
  <nav class="navbar navbar-default">
		<div class="container-fluid">
			<a class="navbar-brand" href="https://sourcecodester.com"></a>
		</div>
	</nav>
	<div class="col-md-3"></div>
	<div class="col-md-6 well">
		<h3 class="text-primary">user_form</h3>
		<hr style="border-top:1px dotted #ccc;"/>
		<button type="button" class="btn btn-success" data-toggle="modal" data-target="#form_modal"><span class="glyphicon glyphicon-plus"></span> Add user</button>
		<a href="archive.php" class="pull-right"></a>
		<br /><br />
		<table class="table table-bordered">
			<thead class="alert-info">
				<tr>
					<th>user_id</th>
					<th> Names</th>
					<th>tel</th>
					<th>id_card</th>
                    
                    <th>email</th>
                    <th>username</th>
                    <th>password</th>
				</tr>
			</thead>
			<tbody style="background-color:#fff;">
				<?php
					require 'conn.php';
					
					$query = mysqli_query($conn, "SELECT * FROM `users`") or die(mysqli_error());
					while($fetch = mysqli_fetch_array($query)){
				?>
				<tr>
					<td><?php echo $fetch['user_id']?></td>
					<td><?php echo $fetch['names']?></td>
					<td></td>
					<td><?php echo $fetch['id_card']?></td>
                 
                    <td><?php echo $fetch['email']?></td>
                    <td><?php echo $fetch['username']?></td>
                    <td><?php echo $fetch['password']?></td>
				</tr>
				<?php
					}
				?>
			</tbody>
		</table>
	</div>
	<div class="modal fade" id="form_modal" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST" action="save_users.php">
					<div class="modal-header">
						<h3 class="modal-title">Add users</h3>
					</div>
					<div class="modal-body">
						<div class="col-md-2"></div>
						<div class="col-md-8">
							<div class="form-group">
								<label>user_id</label>
								<input type="text" name="user_id" class="form-control" required="required"/>
							</div>
							
                         
                               </div>
                            <div class="form-group">
                                <label>id_card</label>
								<input type="text" name="id_card"class="form-control" required="required"/>
							</div>
                               </div>
                            <div class="form-group">
                                <label>types</label>
								<input type="text" name="types"class="form-control"required="required/>
							</div>
                              
                              
                            
                              
                            

                            <div class="form-group">
                                <label>email </label>
                              <input type="text" names ="email"class="form-control" required="required"/>
                              
                                 </div>
                              <div class="form-group">
                                  <label>username</label/>
								<input type="text" name="username"class="form-control"required="required"/>
							</div>
                              
                              
                              
                                         
                                    
                                                                                                                                                                              
                                                                                                       
							
							<div class="form-group">
                                <label>password</label>
								<input type="date" name=" password class="form-control" required="required" />
							</div>
						</div>
					</div>
					<div style="clear:both;"></div>
					<div class="modal-footer">
						<button name="save" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
						<button class="btn btn-danger" type="button" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Close</button>
					</div>
					</div>
				</form>
			</div>
		</div>
	</div>    
    
        
 
  
    
    <body>
      
  <nav class="navbar navbar-default">
		<div class="container-fluid">
			<a class="navbar-brand" href="https://sourcecodester.com"></a>
		</div>
	</nav>
	<div class="col-md-3"></div>
	<div class="col-md-6 well">
		<h3 class="text-primary">pond_id/h3>
		<hr style="border-top:1px dotted #ccc;"/>
		<button type="button" class="btn btn-success" data-toggle="modal" data-target="#form_modal"><span class="glyphicon glyphicon-plus"></span> Add ponds</button>
		<a href="archive.php" class="pull-right"></a>
		<br /><br />
		<table class="table table-bordered">
			<thead class="alert-info">
				<tr>
					<th>pond_id</th>
					<th> pond_description</th>
					<th>pond_address</th>
					<th>user_id</th>
                    
        
				</tr>
			</thead>
			<tbody style="background-color:#fff;">
				<?php
					require 'conn.php';
					
					$query = mysqli_query($conn, "SELECT * FROM `users`") or die(mysqli_error());
					while($fetch = mysqli_fetch_array($query)){
				?>
				<tr>
					<td><?php echo $fetch['pond_id']?></td>
					<td><?php echo $fetch['pond_description']?></td>
					<td></td>
					<td><?php echo $fetch['pond_address']?></td>
                 
                    <td><?php echo $fetch['user_id']?></td>
                   
				</tr>
				<?php
					}
				?>
			</tbody>
		</table>
	</div>
	<div class="modal fade" id="form_modal" aria-hidden="true">
		<div class="modal-dialog">
			<div class="modal-content">
				<form method="POST" action="save_users.php">
					<div class="modal-header">
						<h3 class="modal-title">Add pond</h3>
					</div>
					<div class="modal-body">
						<div class="col-md-2"></div>
						<div class="col-md-8">
							<div class="form-group">
								<label>pond_id</label>
								<input type="text" name="pond_id" class="form-control" required="required"/>
							</div>
							
                         
                               </div>
                            <div class="form-group">
                                <label>pond_description</label>
								<input type="text" name="pond_description"class="form-control" required="required"/>
							</div>
                               </div>
                            <div class="form-group">
                                <label>pond_address</label>
								<input type="text" name="pond_address"class="form-control"required="required/>
							</div>
                              <div class="form-group">
                                <label>user_id</label>
								<input type="text" name="user_id"class="form-control"required="required/>
							</div>
                              
                            
                              
                            

                              
                              
                              
                                         
                                    
                                                                                                                                                                              
                                                                                                       
							
							
					<div style="clear:both;"></div>
					<div class="modal-footer">
						<button name="save" class="btn btn-primary"><span class="glyphicon glyphicon-save"></span> Save</button>
						<button class="btn btn-danger" type="button" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Close</button>
					</div>
					</div>
				</form>
			</div>
		</div>
	</div>           
        
        
     



























        
        
        
        
        
        
        
        
  </body>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/npm.js"></script>
</html>