<?php
	$conn = mysqli_connect("localhost", "root", "", "water_monitoring");
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>